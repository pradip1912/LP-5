
import java.rmi.*;
public class SumClient extends Thread implements Runnable 
	{
	int c,d;
	SumClient(int c,int d){
		this.c=c;
		this.d=d;
	}
	public void run()  
	    	{    
		System.out.println("Thread is running..."); 
		System.out.println(Thread.currentThread().getName()); 
		try 
			{        	
			
			String sumServerURL = "rmi://localhost/SUM-SERVER";
			SumServerIntf sumServerIntf = (SumServerIntf)Naming.lookup(sumServerURL);		
			System.out.println("The sum is: " + sumServerIntf.sum(c, d)); 
			
			}
			catch(Exception e) 
			{
			System.out.println("Exception: " + e);
			
			}  
    		}    
	
	public static void main(String args[]) 
		{
		int m=5,n=7;
		int j=8,k=9;				
		SumClient thread1=new SumClient(m,n); 
		thread1.start();
		SumClient thread2=new SumClient(j,k);    
               	thread2.start();        
        		
		}
}
